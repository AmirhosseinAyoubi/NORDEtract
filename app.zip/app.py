from flask import Flask, request, jsonify, send_file, make_response
from flask_cors import CORS
import pandas as pd
import numpy as np
import io
import json
import plotly.graph_objs as go
import plotly.utils
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import os
from datetime import datetime
import base64
import tempfile
import gc
import matplotlib
matplotlib.use('Agg')  # Use non-interactive backend
import matplotlib.pyplot as plt
import re
import time
from typing import Dict, Any, List, Tuple, Optional
from enhanced_data_cleaning_engine import EnhancedDataCleaningEngine
from advanced_merging_engine import AdvancedMergingEngine

app = Flask(__name__)

# Configure CORS for separate frontend
CORS(app, 
     origins=['*'],  # Temporarily allow all origins for debugging
     allow_headers=['*'],
     methods=['*'],
     supports_credentials=False)

# Configure Flask for unlimited file uploads with optimizations
app.config['MAX_CONTENT_LENGTH'] = None  # No file size limit
app.config['UPLOAD_TIMEOUT'] = 1200  # 20 minutes timeout

# Global storage for datasets
datasets = {}
quality_reports = {}

@app.route('/')
def index():
    return jsonify({'message': 'Data Quality AI Backend', 'status': 'running', 'version': '1.0.0'})

@app.route('/api/upload', methods=['OPTIONS'])
def handle_options():
    """Handle CORS preflight requests"""
    return '', 200

@app.route('/api/upload', methods=['POST'])
def upload_file():
    temp_file_path = None
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file provided'}), 400

        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400

        print(f"🚀 Starting upload: {file.filename}")
        
        # Create secure temporary file with proper extension
        file_ext = os.path.splitext(file.filename)[1].lower()
        temp_fd, temp_file_path = tempfile.mkstemp(suffix=file_ext)
        
        # Stream file to disk efficiently
        chunk_size = 1024 * 1024  # 1MB chunks for faster streaming
        bytes_written = 0
        
        print(f"📥 Streaming file to disk...")
        with os.fdopen(temp_fd, 'wb') as temp_file:
            while True:
                chunk = file.read(chunk_size)
                if not chunk:
                    break
                temp_file.write(chunk)
                bytes_written += len(chunk)
                
                # Progress every 50MB for large files
                if bytes_written % (50 * 1024 * 1024) == 0:
                    print(f"📊 Streamed: {bytes_written / (1024*1024):.0f}MB")

        print(f"✅ File streamed: {bytes_written / (1024*1024):.1f}MB")

        # Process based on file type with robust error handling
        df = None
        if file_ext == '.csv':
            df = process_large_csv(temp_file_path)
        elif file_ext in ['.xlsx', '.xls']:
            df = process_large_excel(temp_file_path, file_ext)
        else:
            return jsonify({'error': 'Unsupported file type. Supported: CSV, XLSX, XLS'}), 400

        if df is None:
            return jsonify({'error': 'Failed to read file. Check file format and encoding.'}), 400
            
        if len(df) == 0:
            return jsonify({'error': 'File is empty or contains no valid data.'}), 400

        print(f"🎯 Data loaded: {len(df):,} rows × {len(df.columns)} columns")

        # Generate unique dataset ID
        dataset_id = f"dataset_{int(datetime.now().timestamp())}"
        
        # Store dataset efficiently
        datasets[dataset_id] = {
            'data': df,
            'filename': file.filename,
            'uploaded_at': datetime.now().isoformat(),
            'file_size': bytes_written,
            'rows': len(df),
            'columns': len(df.columns)
        }

        # Generate optimized quality report
        print(f"📊 Generating quality report...")
        report = create_fast_quality_report(df)
        quality_reports[dataset_id] = report
        
        # Generate comprehensive report
        print(f"📊 Generating comprehensive report...")
        comprehensive_report = generate_comprehensive_report(df, dataset_id, file.filename)

        # Create safe response
        response_data = {
            'dataset_id': dataset_id,
            'filename': file.filename,
            'rows': len(df),
            'columns': len(df.columns),
            'file_size': bytes_written,
            'preview': create_safe_preview(df),
            'schema': create_safe_schema(df),
            'quality_report': report
        }
        
        # Clean any remaining NaN values in the response
        response_data = clean_nan_values(response_data)

        print(f"✅ Upload complete: {file.filename}")
        return jsonify(response_data)

    except MemoryError:
        return jsonify({'error': 'File too large for available memory. Try: 1) Convert Excel to CSV, 2) Split file into smaller parts, 3) Increase system memory.'}), 413
    except Exception as e:
        error_msg = str(e)
        print(f"❌ Upload error: {error_msg}")
        
        if 'memory' in error_msg.lower():
            return jsonify({'error': 'Memory limit exceeded. File is too large.'}), 413
        elif 'permission' in error_msg.lower():
            return jsonify({'error': 'File access error. Try saving file in a different format.'}), 403
        elif 'encoding' in error_msg.lower() or 'decode' in error_msg.lower():
            return jsonify({'error': 'File encoding error. Try saving as UTF-8 CSV.'}), 400
        else:
            return jsonify({'error': f'Upload failed: {error_msg}'}), 500
    
    finally:
        # Always cleanup temp file
        if temp_file_path and os.path.exists(temp_file_path):
            try:
                os.unlink(temp_file_path)
                print(f"🧹 Cleaned up temporary file")
            except Exception as e:
                print(f"⚠️ Cleanup warning: {e}")

def process_large_csv(file_path):
    """Process large CSV files with optimized memory usage"""
    encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252', 'utf-16']
    
    for encoding in encodings:
        try:
            print(f"🔍 Trying {encoding} encoding...")
            
            # For very large files, use chunked reading
            file_size = os.path.getsize(file_path)
            if file_size > 500 * 1024 * 1024:  # >500MB
                print(f"📚 Large file detected ({file_size/(1024*1024):.0f}MB), using chunked reading...")
                return read_csv_in_chunks(file_path, encoding)
            else:
                # For smaller files, read normally
                df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"✅ Successfully read with {encoding}")
                return df
                
        except UnicodeDecodeError:
            continue
        except Exception as e:
            if 'codec' not in str(e).lower() and 'decode' not in str(e).lower():
                print(f"❌ CSV error: {e}")
                break
    
    print(f"❌ Failed to read CSV with any encoding")
    return None

def read_csv_in_chunks(file_path, encoding):
    """Read large CSV in chunks to manage memory"""
    try:
        chunk_size = 100000  # 100k rows per chunk
        chunks = []
        total_rows = 0
        max_chunks = 50  # Limit to ~5M rows max
        
        print(f"📖 Reading CSV in {chunk_size:,} row chunks...")
        
        for i, chunk in enumerate(pd.read_csv(file_path, encoding=encoding, chunksize=chunk_size, low_memory=False)):
            chunks.append(chunk)
            total_rows += len(chunk)
            
            if i % 10 == 0:  # Progress every 10 chunks (1M rows)
                print(f"📊 Processed {total_rows:,} rows...")
            
            if len(chunks) >= max_chunks:
                print(f"⚠️ File very large, limiting to first {total_rows:,} rows")
                break
        
        if chunks:
            print(f"🔗 Combining {len(chunks)} chunks...")
            df = pd.concat(chunks, ignore_index=True)
            print(f"✅ Final dataset: {len(df):,} rows")
            return df
        
        return None
        
    except Exception as e:
        print(f"❌ Chunked reading failed: {e}")
        return None

def process_large_excel(file_path, file_ext):
    """Process large Excel files with memory optimization"""
    try:
        file_size = os.path.getsize(file_path)
        print(f"📊 Processing Excel file ({file_size/(1024*1024):.1f}MB)...")
        
        if file_size > 200 * 1024 * 1024:  # >200MB
            print(f"⚠️ Very large Excel file. Consider converting to CSV for better performance.")
        
        engine = 'openpyxl' if file_ext == '.xlsx' else 'xlrd'
        df = pd.read_excel(file_path, engine=engine)
        
        print(f"✅ Excel loaded: {len(df):,} rows × {len(df.columns)} columns")
        return df
        
    except Exception as e:
        print(f"❌ Excel processing failed: {e}")
        return None

def read_large_csv_streaming_old(file_path, filename):
    """Optimized CSV reading for large files"""
    encodings = ['utf-8', 'latin-1', 'iso-8859-1', 'cp1252', 'utf-16']
    
    for encoding in encodings:
        try:
            print(f"Trying to read CSV with {encoding} encoding...")
            # Use chunked reading for very large files
            chunk_size = 50000  # Read in 50k row chunks
            chunks = []
            
            try:
                # First, try to read normally for smaller files
                df = pd.read_csv(file_path, encoding=encoding, low_memory=False)
                print(f"Successfully read CSV with {encoding} encoding")
                return df
            except MemoryError:
                print(f"Memory error, trying chunked reading...")
                # If memory error, read in chunks
                for chunk in pd.read_csv(file_path, encoding=encoding, chunksize=chunk_size, low_memory=False):
                    chunks.append(chunk)
                    if len(chunks) > 100:  # Limit to ~5M rows max
                        print(f"File too large, using first {len(chunks) * chunk_size} rows")
                        break
                
                if chunks:
                    df = pd.concat(chunks, ignore_index=True)
                    print(f"Successfully read CSV with chunked reading: {len(df)} rows")
                    return df
                    
        except (UnicodeDecodeError, UnicodeError):
            continue
        except Exception as e:
            if 'codec' not in str(e) and 'decode' not in str(e):
                print(f"Error reading CSV: {str(e)}")
                break
    
    return None

def read_large_excel_streaming(file_path, filename):
    """Optimized Excel reading for large files"""
    try:
        print(f"Reading Excel file...")
        # Try to read Excel file with optimization
        df = pd.read_excel(file_path, engine='openpyxl' if filename.endswith('.xlsx') else 'xlrd')
        print(f"Successfully read Excel file: {len(df)} rows")
        return df
    except MemoryError:
        # For very large Excel files, suggest conversion to CSV
        raise Exception("Excel file too large for memory. Please convert to CSV format for better performance.")
    except Exception as e:
        print(f"Error reading Excel: {str(e)}")
        raise e

def calculate_unified_quality_score(df):
    """Calculate quality score according to policy.json"""
    try:
        total_rows = len(df)
        score = 100.0
        penalties = []
        
        # Policy configuration
        policy = {
            "baseline": {
                "duplicates": {"scale": 0.1, "max_penalty": 3},
                "constant_columns": {"per_column": 1, "max_penalty": 5},
                "missing_values": {"scale": 0.05, "max_penalty": 5},
                "outliers": {"scale": 0.05, "max_penalty": 3}
            },
            "context": {
                "DAYS_BIRTH": {"non_negative_penalty": 1, "max_age": 120, "age_penalty": 1},
                "DAYS_EMPLOYED": {"positive_penalty": 1},
                "AMT_INCOME_TOTAL": {"max_value": 100000000, "penalty": 2},
                "TARGET": {"non_binary_penalty": 2},
                "FLAG_*": {"non_binary_penalty": 1}
            },
            "grades": {"A": 85, "B": 70, "C": 55, "D": 40}
        }
        
        # 1. Duplicates penalty (baseline)
        duplicate_rows_pct = 100.0 * df.duplicated().sum() / max(1, len(df))
        if duplicate_rows_pct > 0:
            dup_penalty = min(duplicate_rows_pct * policy["baseline"]["duplicates"]["scale"], 
                            policy["baseline"]["duplicates"]["max_penalty"])
            score -= dup_penalty
            penalties.append(f"Duplicates: -{dup_penalty:.1f}")
        
        # 2. Constant columns penalty (baseline)
        constant_columns = [c for c in df.columns if df[c].nunique(dropna=True) <= 1]
        if constant_columns:
            const_penalty = min(len(constant_columns) * policy["baseline"]["constant_columns"]["per_column"],
                              policy["baseline"]["constant_columns"]["max_penalty"])
            score -= const_penalty
            penalties.append(f"Constant columns: -{const_penalty:.1f}")
        
        # 3. Missing values penalty (baseline) - per column
        total_missing_penalty = 0
        for col in df.columns:
            series = df[col]
            miss_pct = (series.isnull().sum() / len(series)) * 100
            if miss_pct > 0:
                col_miss_penalty = min(miss_pct * policy["baseline"]["missing_values"]["scale"],
                                     policy["baseline"]["missing_values"]["max_penalty"])
                total_missing_penalty += col_miss_penalty
        
        # Cap total missing penalty
        total_missing_penalty = min(total_missing_penalty, policy["baseline"]["missing_values"]["max_penalty"])
        if total_missing_penalty > 0:
            score -= total_missing_penalty
            penalties.append(f"Missing values: -{total_missing_penalty:.1f}")
        
        # 4. Outliers penalty (baseline) - per column
        total_outlier_penalty = 0
        for col in df.columns:
            series = df[col]
            if series.dtype in ['int64', 'float64'] and len(series.dropna()) > 0:
                s = series.dropna()
                Q1 = s.quantile(0.25)
                Q3 = s.quantile(0.75)
                IQR = Q3 - Q1
                if IQR > 0:
                    outliers = ((s < (Q1 - 1.5 * IQR)) | (s > (Q3 + 1.5 * IQR))).sum()
                    if outliers > 0:
                        out_density = 100.0 * (outliers / total_rows)
                        col_outlier_penalty = min(out_density * policy["baseline"]["outliers"]["scale"],
                                                policy["baseline"]["outliers"]["max_penalty"])
                        total_outlier_penalty += col_outlier_penalty
        
        # Cap total outlier penalty
        total_outlier_penalty = min(total_outlier_penalty, policy["baseline"]["outliers"]["max_penalty"])
        if total_outlier_penalty > 0:
            score -= total_outlier_penalty
            penalties.append(f"Outliers: -{total_outlier_penalty:.1f}")
        
        # 5. Context-specific penalties
        context_penalties = 0
        
        # DAYS_BIRTH context
        if 'DAYS_BIRTH' in df.columns:
            birth_series = df['DAYS_BIRTH'].dropna()
            if len(birth_series) > 0:
                # Non-negative penalty
                negative_count = (birth_series > 0).sum()
                if negative_count > 0:
                    context_penalties += policy["context"]["DAYS_BIRTH"]["non_negative_penalty"]
                
                # Age penalty (too old)
                old_count = (birth_series < -policy["context"]["DAYS_BIRTH"]["max_age"] * 365).sum()
                if old_count > 0:
                    context_penalties += policy["context"]["DAYS_BIRTH"]["age_penalty"]
        
        # DAYS_EMPLOYED context
        if 'DAYS_EMPLOYED' in df.columns:
            emp_series = df['DAYS_EMPLOYED'].dropna()
            if len(emp_series) > 0:
                # Positive penalty (should be negative)
                positive_count = (emp_series > 0).sum()
                if positive_count > 0:
                    context_penalties += policy["context"]["DAYS_EMPLOYED"]["positive_penalty"]
        
        # AMT_INCOME_TOTAL context
        if 'AMT_INCOME_TOTAL' in df.columns:
            income_series = df['AMT_INCOME_TOTAL'].dropna()
            if len(income_series) > 0:
                # Max value penalty
                high_income_count = (income_series > policy["context"]["AMT_INCOME_TOTAL"]["max_value"]).sum()
                if high_income_count > 0:
                    context_penalties += policy["context"]["AMT_INCOME_TOTAL"]["penalty"]
        
        # TARGET context
        if 'TARGET' in df.columns:
            target_series = df['TARGET'].dropna()
            if len(target_series) > 0:
                # Non-binary penalty
                unique_values = target_series.nunique()
                if unique_values > 2:
                    context_penalties += policy["context"]["TARGET"]["non_binary_penalty"]
        
        # FLAG_* columns context
        flag_columns = [c for c in df.columns if c.startswith('FLAG_')]
        for col in flag_columns:
            flag_series = df[col].dropna()
            if len(flag_series) > 0:
                # Non-binary penalty
                unique_values = flag_series.nunique()
                if unique_values > 2:
                    context_penalties += policy["context"]["FLAG_*"]["non_binary_penalty"]
        
        if context_penalties > 0:
            score -= context_penalties
            penalties.append(f"Context violations: -{context_penalties:.1f}")
        
        # Ensure score is between 0 and 100
        score = max(0, min(100, score))
        
        # Calculate grade according to policy
        if score >= policy["grades"]["A"]:
            grade = "A"
        elif score >= policy["grades"]["B"]:
            grade = "B"
        elif score >= policy["grades"]["C"]:
            grade = "C"
        elif score >= policy["grades"]["D"]:
            grade = "D"
        else:
            grade = "F"
        
        # Debug logging
        if len(penalties) > 0:
            print(f"📊 Scoring penalties: {'; '.join(penalties)}")
        
        return round(score, 1), grade
        
    except Exception as e:
        print(f"❌ Error calculating unified score: {e}")
        return 0.0, "F"

def create_fast_quality_report(df):
    """Generate quality report with memory optimization for large datasets"""
    try:
        print(f"📊 Analyzing data quality...")
        
        total_rows = len(df)
        total_cols = len(df.columns)
        
        # Sample for analysis if dataset is very large
        if total_rows > 500000:
            sample_size = min(100000, total_rows)
            df_sample = df.sample(n=sample_size, random_state=42)
            print(f"📋 Using sample of {sample_size:,} rows for quality analysis")
        else:
            df_sample = df
        
        # Use unified scoring system
        quality_score, grade = calculate_unified_quality_score(df_sample)
        
        # Basic statistics
        missing_values = df_sample.isnull().sum().sum()
        missing_percent = (missing_values / (len(df_sample) * len(df_sample.columns))) * 100
        
        # Duplicates check (on sample for large files)
        duplicates = df_sample.duplicated().sum()
        duplicate_percent = (duplicates / len(df_sample)) * 100
        
        # Data types
        numeric_cols = df_sample.select_dtypes(include=[np.number]).columns.tolist()
        categorical_cols = df_sample.select_dtypes(include=['object', 'category']).columns.tolist()
        
        return {
            'quality_score': quality_score,
            'grade': grade,
            'total_rows': total_rows,
            'total_columns': total_cols,
            'missing_values': int(missing_values),
            'missing_percent': round(missing_percent, 2),
            'duplicates': int(duplicates),
            'duplicate_percent': round(duplicate_percent, 2),
            'numeric_columns': len(numeric_cols),
            'categorical_columns': len(categorical_cols),
            'data_types': {col: str(dtype) for col, dtype in df_sample.dtypes.items()},
            'sample_stats': create_sample_stats(df_sample, numeric_cols[:10])  # Limit to 10 cols
        }
        
    except Exception as e:
        print(f"❌ Quality report error: {e}")
        return {
            'quality_score': 0,
            'grade': 'F',
            'total_rows': len(df) if df is not None else 0,
            'total_columns': len(df.columns) if df is not None else 0,
            'error': str(e)
        }

def create_sample_stats(df, numeric_cols):
    """Create basic statistics for numeric columns"""
    try:
        stats = {}
        for col in numeric_cols[:5]:  # Limit to 5 columns for performance
            try:
                col_data = df[col].dropna()
                if len(col_data) > 0:
                    stats[col] = {
                        'min': format_decimal(float(col_data.min())),
                        'max': format_decimal(float(col_data.max())),
                        'mean': format_decimal(float(col_data.mean())),
                        'median': format_decimal(float(col_data.median())),
                        'std': format_decimal(float(col_data.std())) if len(col_data) > 1 else 0
                    }
            except Exception:
                continue
        return stats
    except Exception:
        return {}

def create_safe_preview(df):
    """Create safe preview for large datasets"""
    try:
        preview_df = df.head(5).copy()
        # Handle NaN and infinite values more thoroughly
        preview_df = preview_df.where(pd.notnull(preview_df), None)
        preview_df = preview_df.replace([np.inf, -np.inf], None)
        
        # Convert to dict and clean NaN values
        records = preview_df.to_dict('records')
        
        # Clean any remaining NaN values in the records
        for record in records:
            for key, value in record.items():
                if pd.isna(value) or (isinstance(value, float) and np.isnan(value)):
                    record[key] = None
                elif isinstance(value, (np.integer, np.floating)):
                    record[key] = value.item() if not pd.isna(value) else None
        
        return records
    except Exception as e:
        print(f"⚠️ Preview error: {e}")
        return []

def clean_nan_values(obj):
    """Recursively clean NaN values from any data structure"""
    if isinstance(obj, dict):
        return {key: clean_nan_values(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [clean_nan_values(item) for item in obj]
    elif pd.isna(obj) or (isinstance(obj, float) and np.isnan(obj)):
        return None
    elif isinstance(obj, (np.integer, np.floating)):
        return obj.item() if not pd.isna(obj) else None
    else:
        return obj

def create_safe_schema(df):
    """Create safe schema for large datasets"""
    try:
        schema = []
        # Limit to first 20 columns for performance
        for col in df.columns[:20]:
            try:
                dtype = str(df[col].dtype)
                # Get sample values safely
                sample_values = df[col].dropna().head(3).tolist()
                # Ensure JSON serializable
                safe_values = []
                for val in sample_values:
                    if pd.isna(val) or (isinstance(val, float) and np.isnan(val)):
                        safe_values.append(None)
                    elif isinstance(val, (np.integer, np.floating)):
                        safe_values.append(val.item() if not pd.isna(val) else None)
                    elif isinstance(val, (int, float, str, bool)):
                        safe_values.append(val)
                    else:
                        safe_values.append(str(val))
                
                schema.append({
                    'column': str(col),
                    'type': dtype,
                    'sample_values': safe_values
                })
            except Exception:
                continue
        return schema
    except Exception as e:
        print(f"⚠️ Schema error: {e}")
        return []

def generate_quality_report_fast_old(df, dataset_id):
    """Generate quality report with memory optimization"""
    try:
        print(f"Generating quality report for {len(df)} rows...")
        
        # Basic statistics with optimization
        total_rows = len(df)
        total_columns = len(df.columns)
        
        # Memory-efficient missing value calculation
        missing_values = df.isnull().sum().sum()
        missing_percentage = (missing_values / (total_rows * total_columns)) * 100
        
        # Memory-efficient duplicate calculation
        duplicates = df.duplicated().sum()
        duplicate_percentage = (duplicates / total_rows) * 100
        
        # Basic stats for numeric columns only (memory efficient)
        numeric_cols = df.select_dtypes(include=[np.number]).columns[:5]  # Limit to first 5 numeric
        basic_stats = {}
        
        for col in numeric_cols:
            try:
                col_data = df[col].dropna()
                if len(col_data) > 0:
                    basic_stats[col] = {
                        'mean': float(col_data.mean()),
                        'median': float(col_data.median()),
                        'std': float(col_data.std()) if len(col_data) > 1 else 0,
                        'min': float(col_data.min()),
                        'max': float(col_data.max())
                    }
            except Exception as e:
                print(f"Error calculating stats for {col}: {e}")
                continue
        
        # Simple anomaly detection (memory efficient)
        anomalies = 0
        if len(numeric_cols) > 0 and total_rows < 100000:  # Only for reasonable sizes
            try:
                sample_size = min(10000, total_rows)  # Use sample for large datasets
                df_sample = df[numeric_cols].sample(n=sample_size).dropna()
                if len(df_sample) > 100:
                    isolation_forest = IsolationForest(contamination=0.1, random_state=42, n_jobs=1)
                    anomaly_labels = isolation_forest.fit_predict(df_sample)
                    anomalies = int(np.sum(anomaly_labels == -1))
            except Exception as e:
                print(f"Anomaly detection error: {e}")
                anomalies = 0
        
        # Calculate quality score
        quality_score = calculate_quality_score(missing_percentage, duplicate_percentage, anomalies, total_rows)
        
        # Generate AI suggestions
        ai_suggestions = generate_ai_suggestions(missing_percentage, duplicate_percentage, anomalies, df.columns.tolist()[:10])
        
        report = {
            'dataset_id': dataset_id,
            'basic_stats': {
                'total_rows': total_rows,
                'total_columns': total_columns,
                'numeric_columns': len(numeric_cols),
                'missing_percentage': round(missing_percentage, 2),
                'duplicate_percentage': round(duplicate_percentage, 2)
            },
            'issues': {
                'missing_values': int(missing_values),
                'duplicates': int(duplicates),
                'anomalies': int(anomalies)
            },
            'percentages': {
                'missing_percentage': round(missing_percentage, 2),
                'duplicate_percentage': round(duplicate_percentage, 2),
                'unique_percentage': round(100 - duplicate_percentage, 2)
            },
            'column_stats': basic_stats,
            'quality_score': round(quality_score, 1),
            'ai_suggestions': ai_suggestions
        }
        
        print(f"Quality report generated successfully")
        return report
        
    except Exception as e:
        print(f"Error generating quality report: {e}")
        return {
            'dataset_id': dataset_id,
            'basic_stats': {'total_rows': len(df), 'total_columns': len(df.columns)},
            'issues': {'missing_values': 0, 'duplicates': 0, 'anomalies': 0},
            'quality_score': 50.0,
            'ai_suggestions': [{'issue': 'Quality analysis failed', 'suggestion': 'File may be too large or corrupted', 'priority': 'high'}]
        }

def get_safe_preview(df):
    """Get safe preview data for JSON serialization"""
    try:
        preview_df = df.head(5).copy()
        # Replace NaN/inf values for JSON compatibility
        preview_df = preview_df.where(pd.notnull(preview_df), None)
        return preview_df.to_dict('records')
    except Exception as e:
        print(f"Error creating preview: {e}")
        return []

def get_safe_schema(df):
    """Get safe schema data for JSON serialization"""
    try:
        schema = []
        for col in df.columns[:20]:  # Limit to first 20 columns
            try:
                dtype = str(df[col].dtype)
                sample_values = df[col].dropna().head(3).tolist()
                # Ensure JSON serializable
                sample_values = [None if pd.isna(x) else (str(x) if not isinstance(x, (int, float, str, bool)) else x) for x in sample_values]
                schema.append({
                    'column': str(col),
                    'type': dtype,
                    'sample_values': sample_values
                })
            except Exception as e:
                print(f"Error processing column {col}: {e}")
                continue
        return schema
    except Exception as e:
        print(f"Error creating schema: {e}")
        return []

def calculate_quality_score(missing_pct, duplicate_pct, anomalies, total_rows):
    """Calculate overall quality score using policy-based scoring"""
    # Use the same policy as unified scoring
    policy = {
        "baseline": {
            "duplicates": {"scale": 0.1, "max_penalty": 3},
            "missing_values": {"scale": 0.05, "max_penalty": 5},
            "outliers": {"scale": 0.05, "max_penalty": 3}
        }
    }
    
    score = 100.0
    
    # Missing values penalty
    missing_penalty = min(missing_pct * policy["baseline"]["missing_values"]["scale"], 
                         policy["baseline"]["missing_values"]["max_penalty"])
    score -= missing_penalty
    
    # Duplicate penalty
    duplicate_penalty = min(duplicate_pct * policy["baseline"]["duplicates"]["scale"], 
                           policy["baseline"]["duplicates"]["max_penalty"])
    score -= duplicate_penalty
    
    # Anomaly penalty
    if total_rows > 0:
        anomaly_pct = (anomalies / total_rows) * 100
        anomaly_penalty = min(anomaly_pct * policy["baseline"]["outliers"]["scale"], 
                            policy["baseline"]["outliers"]["max_penalty"])
        score -= anomaly_penalty
    
    return max(score, 0)

def generate_ai_suggestions(missing_pct, duplicate_pct, anomalies, columns):
    """Generate AI suggestions based on data quality issues"""
    suggestions = []
    
    if missing_pct > 10:
        suggestions.append({
            'issue': f'High missing values ({missing_pct:.1f}%)',
            'suggestion': 'Consider imputation strategies or removing columns with excessive missing data',
            'priority': 'high' if missing_pct > 25 else 'medium',
            'columns': columns[:5]
        })
    
    if duplicate_pct > 5:
        suggestions.append({
            'issue': f'Duplicate records detected ({duplicate_pct:.1f}%)',
            'suggestion': 'Remove duplicate rows to improve data quality',
            'priority': 'high' if duplicate_pct > 15 else 'medium'
        })
    
    if anomalies > 0:
        suggestions.append({
            'issue': f'Anomalies detected ({anomalies} outliers)',
            'suggestion': 'Review outliers - they may be data entry errors or valid edge cases',
            'priority': 'medium'
        })
    
    if not suggestions:
        suggestions.append({
            'issue': 'Data quality looks good',
            'suggestion': 'No major issues detected. Consider additional validation for domain-specific rules.',
            'priority': 'low'
        })
    
    return suggestions

# Advanced Analytics Functions (from your analysis tools)
def load_policy(path: str = "policy.json") -> dict:
    """Load scoring policy from JSON file"""
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        # Return default policy if file doesn't exist
        return {
            "baseline": {
                "duplicates": {"scale": 0.2, "max_penalty": 5},
                "constant_columns": {"per_column": 1, "max_penalty": 5},
                "missing_values": {"scale": 0.05, "max_penalty": 5},
                "outliers": {"scale": 0.1, "max_penalty": 3}
            },
            "context": {
                "DAYS_BIRTH": {"non_negative_penalty": 1, "max_age": 120, "age_penalty": 1},
                "DAYS_EMPLOYED": {"positive_penalty": 1},
                "AMT_INCOME_TOTAL": {"max_value": 100000000, "penalty": 2},
                "TARGET": {"non_binary_penalty": 2},
                "FLAG_*": {"non_binary_penalty": 1}
            },
            "grades": {"A": 85, "B": 75, "C": 65, "D": 55}
        }

def safe_get(d: Dict, path: List[str], default=None):
    """Safely get nested dictionary values"""
    cur = d
    for k in path:
        if not isinstance(cur, dict) or k not in cur:
            return default
        cur = cur[k]
    return cur

def detect_semantic_type(series: pd.Series) -> str:
    """Infer semantic type with improved heuristics"""
    if pd.api.types.is_bool_dtype(series):
        return "boolean"
    if pd.api.types.is_numeric_dtype(series):
        uniq = series.nunique(dropna=True)
        if uniq < 50 and (uniq / max(1, len(series))) < 0.05:
            return "categorical_candidate"
        return "numeric"
    if pd.api.types.is_datetime64_any_dtype(series):
        return "datetime"
    if pd.api.types.is_object_dtype(series) or pd.api.types.is_string_dtype(series):
        return "text"
    return "unknown"

def outlier_counts(series: pd.Series) -> Dict[str, int]:
    """Compute robust outlier counts (IQR + Z-score)"""
    outliers = {}
    if not pd.api.types.is_numeric_dtype(series):
        return outliers
    s = series.dropna()
    if s.empty:
        return outliers

    q1, q3 = np.percentile(s, [25, 75])
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    outliers["iqr_count"] = int(((s < lower) | (s > upper)).sum())

    mean, std = s.mean(), s.std()
    if std > 0:
        outliers["zscore_count"] = int((np.abs((s - mean) / std) > 3).sum())

    return outliers

def describe_column(col_name: str, col_report: Dict[str, Any]) -> str:
    """Generate human-readable column description"""
    sem = col_report.get("inferred_semantic_type", "unknown")
    missing = col_report.get("missing_pct", 0)
    uniq = col_report.get("unique_count", 0)
    desc = f"{col_name}: {sem} column, {missing:.1f}% missing, {uniq} unique values."
    if sem == "numeric" and "numeric" in col_report:
        stats = col_report["numeric"]["stats"]
        desc += f" Range [{stats.get('min')}, {stats.get('max')}], mean={stats.get('mean'):.2f}."
    elif sem in ["categorical_candidate", "text"]:
        if col_report.get("id_like"):
            desc += " Looks like an ID column (almost all unique)."
        elif "top_values" in col_report:
            top = col_report["top_values"][:3]
            if top:
                examples = ", ".join([f"{v[0]} ({v[2]:.1f}%)" for v in top])
                desc += f" Top values: {examples}."
    return desc

def add_issue(issues_dict, col, issue, suggestion, severity):
    """Add issue to column reports"""
    issues_dict.setdefault(col, {"description": "", "issues": [], "suggestions": []})
    issues_dict[col]["issues"].append(issue)
    if suggestion:
        issues_dict[col]["suggestions"].append({"severity": severity, "action": suggestion})

def standardize_column_name(name: str) -> str:
    """Convert column names to human-readable format"""
    # Replace underscores with spaces
    name = name.replace('_', ' ')
    
    # Capitalize first letter of each word
    name = ' '.join(word.capitalize() for word in name.split())
    
    # Handle common abbreviations
    replacements = {
        'Id': 'ID',
        'Cnt': 'Count',
        'Amt': 'Amount',
        'Avg': 'Average',
        'Max': 'Maximum',
        'Min': 'Minimum',
        'Std': 'Standard',
        'Pct': 'Percentage',
        'Reg': 'Region',
        'Flag': 'Flag',
        'Name': 'Name',
        'Type': 'Type',
        'Mode': 'Mode',
        'Medi': 'Median',
        'Ext': 'External',
        'Source': 'Source',
        'Days': 'Days',
        'Years': 'Years',
        'Obs': 'Observed',
        'Def': 'Default',
        'Circle': 'Circle',
        'Social': 'Social',
        'Phone': 'Phone',
        'Email': 'Email',
        'Mobile': 'Mobile',
        'Work': 'Work',
        'Contact': 'Contact',
        'Last': 'Last',
        'Change': 'Change',
        'Document': 'Document',
        'Req': 'Request',
        'Credit': 'Credit',
        'Bureau': 'Bureau',
        'Hour': 'Hour',
        'Day': 'Day',
        'Week': 'Week',
        'Mon': 'Month',
        'Qrt': 'Quarter',
        'Year': 'Year'
    }
    
    for old, new in replacements.items():
        name = name.replace(old, new)
    
    return name

def format_decimal(value, max_decimals=4):
    """Format decimal numbers with maximum 4 decimal places"""
    if isinstance(value, (int, float)):
        if value == int(value):
            return int(value)
        else:
            return round(float(value), max_decimals)
    return value

def generate_chart_data(df: pd.DataFrame, column_reports: Dict, correlations: Dict, target_balance: Dict) -> Dict[str, Any]:
    """Generate chart data for ApexCharts visualization matching the reference implementation"""
    try:
        charts = {}
        
        # 1. Missing Values Chart (Top 20 columns by missing percentage)
        # Extract missing percentages from column reports
        missing_data = []
        for col_name, report in column_reports.items():
            desc = report.get('description', '')
            if 'missing' in desc:
                try:
                    # Extract missing percentage from description like "0.0% missing"
                    missing_match = re.search(r'(\d+\.?\d*)% missing', desc)
                    if missing_match:
                        missing_pct = format_decimal(float(missing_match.group(1)))
                        if missing_pct > 0:  # Only include columns with actual missing values
                            missing_data.append({'x': standardize_column_name(col_name), 'y': missing_pct})
                except:
                    pass
        
        # Sort by missing percentage and take top 20
        missing_data.sort(key=lambda x: x['y'], reverse=True)
        if len(missing_data) > 1:  # Only show if more than 1 column has missing values
            charts['missingness'] = {
                'series': [{'name': 'Missing %', 'data': missing_data[:20]}],
                'options': {
                    'chart': {'type': 'bar', 'height': 400},
                    'title': {'text': 'Top 20 Columns by Missing Values'},
                    'xaxis': {'title': {'text': 'Columns'}, 'labels': {'rotate': -45}},
                    'yaxis': {'title': {'text': 'Missing %'}},
                    'colors': ['#ef4444'],
                    'dataLabels': {'enabled': False}
                }
            }
        
        # 2. Outliers Chart (Top 20 columns by outlier count)
        outliers_data = []
        for col_name, report in column_reports.items():
            desc = report.get('description', '')
            if 'outliers detected' in desc:
                try:
                    # Extract outlier count from description like "14035 outliers detected"
                    outlier_match = re.search(r'(\d+) outliers detected', desc)
                    if outlier_match:
                        outlier_count = int(outlier_match.group(1))
                        if outlier_count > 0:  # Only include columns with actual outliers
                            outliers_data.append({'x': standardize_column_name(col_name), 'y': outlier_count})
                except:
                    pass
        
        outliers_data.sort(key=lambda x: x['y'], reverse=True)
        if len(outliers_data) > 1:  # Only show if more than 1 column has outliers
            charts['outliers'] = {
                'series': [{'name': 'Outlier Count', 'data': outliers_data[:20]}],
                'options': {
                    'chart': {'type': 'bar', 'height': 400},
                    'title': {'text': 'Top 20 Columns by Outliers (IQR)'},
                    'xaxis': {'title': {'text': 'Columns'}, 'labels': {'rotate': -45}},
                    'yaxis': {'title': {'text': 'Outlier Count'}},
                    'colors': ['#f59e0b'],
                    'dataLabels': {'enabled': False}
                }
            }
        
        # 3. Correlations Chart (Top 15 correlations) - Horizontal bar chart
        if correlations.get('top_pairs') and len(correlations['top_pairs']) > 1:
            corr_data = []
            corr_labels = []
            for pair in correlations['top_pairs'][:15]:
                label1 = standardize_column_name(pair[0])
                label2 = standardize_column_name(pair[1])
                corr_labels.append(f"{label1} vs {label2}"[:40])
                corr_data.append(format_decimal(abs(pair[2])))
            
            # Only show if there are meaningful correlations (not all the same value)
            if len(set(corr_data)) > 1:
                charts['correlations'] = {
                    'series': [{'name': 'Correlation (|r|)', 'data': corr_data}],
                    'options': {
                        'chart': {'type': 'bar', 'height': 400},
                        'title': {'text': 'Top Correlated Pairs'},
                        'xaxis': {'title': {'text': 'Correlation (|r|)'}},
                        'yaxis': {'categories': corr_labels},
                        'colors': ['#3b82f6'],
                        'dataLabels': {'enabled': False}
                    }
                }
        
        # 4. Target Balance Chart (Pie chart for target distribution)
        if target_balance.get('distribution_pct') and len(target_balance['distribution_pct']) > 1:
            target_data = []
            target_labels = []
            for label, pct in target_balance['distribution_pct'].items():
                target_labels.append(str(label))
                target_data.append(format_decimal(pct))
            
            # Only show if there are multiple categories and not all the same value
            if len(target_data) > 1 and len(set(target_data)) > 1:
                charts['target_balance'] = {
                    'series': target_data,
                    'options': {
                        'chart': {'type': 'pie', 'height': 400},
                        'title': {'text': f"Target Distribution ({target_balance.get('column', 'TARGET')})"},
                        'labels': target_labels,
                        'colors': ['#10b981', '#ef4444', '#f59e0b', '#3b82f6', '#8b5cf6'],
                        'dataLabels': {'enabled': True, 'format': '{percentage:.1f}%'}
                    }
                }
        
        return charts
        
    except Exception as e:
        print(f"❌ Error generating chart data: {e}")
        return {}

def generate_dataset_description(df: pd.DataFrame, filename: str, score: float, grade: str) -> str:
    """Generate a smart description for the dataset based on actual data analysis"""
    try:
        rows = len(df)
        cols = len(df.columns)
        
        # Analyze data characteristics
        numeric_cols = df.select_dtypes(include=[np.number]).shape[1]
        categorical_cols = df.select_dtypes(include=['object', 'category']).shape[1]
        datetime_cols = df.select_dtypes(include=['datetime64']).shape[1]
        
        # Determine dataset type based on actual content analysis
        dataset_type = "Dataset"
        
        # Check for common patterns in column names and data
        col_names = [col.lower() for col in df.columns]
        
        # Financial/Credit analysis
        financial_indicators = ['amount', 'amt_', 'credit', 'loan', 'payment', 'balance', 'income', 'debt', 'interest', 'rate']
        if any(any(indicator in col for indicator in financial_indicators) for col in col_names):
            if any('application' in col or 'app' in col for col in col_names):
                dataset_type = "Credit Application"
            elif any('bureau' in col or 'credit' in col for col in col_names):
                dataset_type = "Credit Bureau"
            elif any('payment' in col or 'installment' in col for col in col_names):
                dataset_type = "Payment History"
            elif any('balance' in col for col in col_names):
                dataset_type = "Account Balance"
            else:
                dataset_type = "Financial Dataset"
        
        # Time series analysis
        elif any('date' in col or 'time' in col or 'day' in col for col in col_names):
            dataset_type = "Time Series Dataset"
        
        # Customer/User analysis
        elif any('customer' in col or 'user' in col or 'client' in col or 'id' in col for col in col_names):
            dataset_type = "Customer Dataset"
        
        # Product/Catalog analysis
        elif any('product' in col or 'item' in col or 'category' in col for col in col_names):
            dataset_type = "Product Dataset"
        
        # Determine data quality level
        if grade == 'A':
            quality_desc = "excellent quality"
        elif grade == 'B':
            quality_desc = "good quality"
        elif grade == 'C':
            quality_desc = "moderate quality"
        elif grade == 'D':
            quality_desc = "poor quality"
        else:
            quality_desc = "very poor quality"
        
        # Analyze data composition
        if numeric_cols > categorical_cols * 2:
            content_desc = "primarily numerical data"
        elif categorical_cols > numeric_cols * 2:
            content_desc = "primarily categorical data"
        else:
            content_desc = "mixed numerical and categorical data"
        
        # Analyze data completeness
        total_cells = rows * cols
        missing_cells = df.isnull().sum().sum()
        completeness = ((total_cells - missing_cells) / total_cells) * 100
        
        if completeness > 95:
            completeness_desc = "highly complete"
        elif completeness > 80:
            completeness_desc = "mostly complete"
        elif completeness > 60:
            completeness_desc = "moderately complete"
        else:
            completeness_desc = "incomplete"
        
        # Analyze data distribution
        if numeric_cols > 0:
            numeric_data = df.select_dtypes(include=[np.number])
            has_outliers = False
            for col in numeric_data.columns:
                if numeric_data[col].dtype in ['int64', 'float64']:
                    Q1 = numeric_data[col].quantile(0.25)
                    Q3 = numeric_data[col].quantile(0.75)
                    IQR = Q3 - Q1
                    outliers = ((numeric_data[col] < (Q1 - 1.5 * IQR)) | (numeric_data[col] > (Q3 + 1.5 * IQR))).sum()
                    if outliers > rows * 0.05:  # More than 5% outliers
                        has_outliers = True
                        break
        
        # Check for target variable
        target_indicators = ['target', 'label', 'class', 'outcome', 'result', 'y']
        has_target = any(any(indicator in col for indicator in target_indicators) for col in col_names)
        
        # Generate smart description
        description_parts = [
            f"{dataset_type} with {rows:,} records and {cols} columns",
            f"Contains {content_desc} with {completeness_desc} data ({completeness:.1f}% complete)",
            f"Data quality: {quality_desc} (Score: {score:.1f})"
        ]
        
        # Add specific insights
        if has_target:
            description_parts.append("Includes target variable for supervised learning")
        
        if numeric_cols > 0 and has_outliers:
            description_parts.append("Contains outliers that may need treatment")
        
        if datetime_cols > 0:
            description_parts.append("Includes temporal data for time series analysis")
        
        # Scale classification
        if rows > 1000000:
            description_parts.append("Large-scale dataset suitable for machine learning applications")
        elif rows > 100000:
            description_parts.append("Medium-scale dataset with substantial data for analysis")
        elif rows > 10000:
            description_parts.append("Moderate-scale dataset ideal for statistical analysis")
        else:
            description_parts.append("Compact dataset perfect for exploratory analysis")
        
        # Add data characteristics
        if numeric_cols > 0:
            numeric_stats = df.select_dtypes(include=[np.number]).describe()
            high_variance_cols = (numeric_stats.loc['std'] / numeric_stats.loc['mean']).dropna()
            if len(high_variance_cols) > 0 and high_variance_cols.max() > 2:
                description_parts.append("High variance in numerical features detected")
        
        # Join all parts
        description = ". ".join(description_parts) + "."
        
        return description
        
    except Exception as e:
        print(f"❌ Error generating dataset description: {e}")
        return f"Dataset with {len(df):,} rows and {len(df.columns)} columns. Quality score: {score:.1f} ({grade})."

def generate_comprehensive_report(df: pd.DataFrame, dataset_id: str, filename: str) -> Dict[str, Any]:
    """Generate comprehensive report using the build_dataset_summary.py approach"""
    try:
        print(f"🔍 Generating comprehensive report for {filename} ({len(df)} rows)...")
        
        # Create dataset directory
        dataset_dir = f"reports/{dataset_id}_{filename.replace('.', '_')}"
        os.makedirs(dataset_dir, exist_ok=True)
        
        # Load policy
        policy = load_policy()
        
        # Basic dataset info
        general = {
            "dataset_name": filename,
            "total_rows": int(len(df)),
            "total_columns": int(df.shape[1]),
            "memory_usage_bytes": int(df.memory_usage(deep=True).sum()),
            "duplicate_rows_count": int(df.duplicated().sum()),
            "duplicate_rows_pct": 100.0 * df.duplicated().sum() / max(1, len(df)),
            "fully_null_rows_count": int(df.isna().all(axis=1).sum()),
            "empty_columns": [c for c in df.columns if df[c].isna().all()],
            "constant_columns": [c for c in df.columns if df[c].nunique(dropna=True) <= 1],
            "candidate_id_columns": [c for c in df.columns if df[c].nunique(dropna=True) == len(df)]
        }
        
        # Use unified scoring system for consistency
        score, grade = calculate_unified_quality_score(df)
        
        # Column analysis
        column_reports = {}
        total_rows = len(df)
        global_notes = []
        
        for col in df.columns:
            series = df[col]
            s = series.dropna()
            
            # Basic column info
            col_report = {
                "original_dtype": str(series.dtype),
                "inferred_semantic_type": detect_semantic_type(series),
                "missing_count": int(series.isna().sum()),
                "missing_pct": 100.0 * series.isna().sum() / total_rows if total_rows > 0 else 0,
                "unique_count": int(series.nunique()),
                "unique_ratio": series.nunique() / total_rows if total_rows > 0 else 0,
                "is_constant": series.nunique() <= 1,
                "is_low_variance": (series.nunique() / total_rows) < 0.01 and series.nunique() > 1
            }
            
            # Numeric analysis
            if col_report["inferred_semantic_type"] == "numeric":
                desc = series.describe().to_dict()
                col_report["numeric"] = {
                    "stats": {k: float(v) for k, v in desc.items()},
                    "outliers": outlier_counts(series)
                }
            
            # Categorical/text analysis
            if col_report["inferred_semantic_type"] in ["categorical_candidate", "text"]:
                if col_report["unique_ratio"] > 0.95:
                    col_report["id_like"] = True
                    col_report["top_values"] = []
                else:
                    vc = s.value_counts(normalize=False).head(10)
                    total_non_na = len(s)
                    col_report["top_values"] = [
                        (str(idx), int(cnt), float(cnt) / total_non_na * 100.0)
                        for idx, cnt in vc.items()
                    ]
            
            # Generate description and issues
            col_name = col
            column_reports[col_name] = {
                "description": describe_column(col_name, col_report),
                "issues": [],
                "suggestions": []
            }
            
            # Missing values penalty
            miss_pct = col_report["missing_pct"]
            if miss_pct > 0:
                sev = "major" if miss_pct > 50 else "moderate"
                add_issue(column_reports, col_name,
                          f"{miss_pct:.1f}% missing values",
                          "Impute (mean/median/mode) or drop column if too high", sev)
            
            # Outlier penalty
            if col_report["inferred_semantic_type"] == "numeric":
                out_iqr = col_report["numeric"]["outliers"].get("iqr_count", 0)
                if out_iqr > 0:
                    add_issue(column_reports, col_name,
                              f"{out_iqr} outliers detected",
                              "Cap values at IQR bounds or use robust scaling", "moderate")
            
            # High-cardinality penalty
            if col_report["inferred_semantic_type"] in ["categorical_candidate", "text"]:
                if col_report["unique_ratio"] > 0.95:
                    add_issue(column_reports, col_name,
                              "High-cardinality categorical (ID-like)",
                              "Drop or only use as join key", "major")
        
        # Duplicates penalty
        dup_pct = general["duplicate_rows_pct"]
        if dup_pct > 0:
            global_notes.append(f"High duplicate rows ({dup_pct:.2f}%) — consider dropping duplicates")
        
        # Constant columns penalty
        const_cols = general["constant_columns"]
        if const_cols:
            for c in const_cols:
                add_issue(column_reports, c, "Constant column", "Drop this column", "major")
        
        # Correlation analysis
        numeric_cols = df.select_dtypes(include=[np.number])
        correlations = {"top_pairs": []}
        if not numeric_cols.empty and numeric_cols.shape[1] > 1:
            corr = numeric_cols.corr(method="pearson")
            corr_pairs = []
            for i in range(len(corr.columns)):
                for j in range(i + 1, len(corr.columns)):
                    c1, c2 = corr.columns[i], corr.columns[j]
                    val = corr.iloc[i, j]
                    if not pd.isna(val):
                        corr_pairs.append((c1, c2, float(val)))
            corr_pairs_sorted = sorted(corr_pairs, key=lambda x: abs(x[2]), reverse=True)[:20]
            correlations["top_pairs"] = corr_pairs_sorted
        
        # Target balance check
        target_balance = {}
        for c in df.columns:
            if re.match(r"(?i)target", c):
                vc = df[c].value_counts(normalize=True)
                imbalance = {str(k): float(v * 100) for k, v in vc.items()}
                target_balance = {"column": c, "distribution_pct": imbalance}
                break
        
        # Score and grade already calculated by unified scoring function
        
        # Generate chart data for ApexCharts
        chart_data = generate_chart_data(df, column_reports, correlations, target_balance)
        
        # Generate dataset description
        description = generate_dataset_description(df, filename, score, grade)
        
        # Build comprehensive report
        report = {
            "header": {
                "dataset_name": general["dataset_name"],
                "rows": general["total_rows"],
                "columns": general["total_columns"],
                "credibility": {"score": round(score, 1), "grade": grade},
                "description": description
            },
            "body": {
                "global_issues": global_notes,
                "column_reports": column_reports,
                "correlations": correlations,
                "target_balance": target_balance,
                "general_stats": {
                    "duplicate_rows_pct": round(general["duplicate_rows_pct"], 2),
                    "empty_columns": general["empty_columns"],
                    "constant_columns": general["constant_columns"],
                    "candidate_id_columns": general["candidate_id_columns"]
                },
                "charts": chart_data
            },
            "footer": {
                "notes": ["Comprehensive data quality analysis with policy-driven scoring"],
                "generated_by": "Enhanced Data Quality System"
            }
        }
        
        # Save report to dataset directory
        report_path = os.path.join(dataset_dir, "summary_report.json")
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        
        print(f"✅ Comprehensive report generated - Score: {score:.1f} ({grade})")
        print(f"📁 Report saved to: {report_path}")
        return report
        
    except Exception as e:
        print(f"❌ Error generating comprehensive report: {e}")
        return {
            "header": {"dataset_name": filename, "rows": len(df), "columns": len(df.columns), "credibility": {"score": 0, "grade": "F"}},
            "body": {"global_issues": [f"Report generation failed: {str(e)}"], "column_reports": {}, "correlations": {"top_pairs": []}, "target_balance": {}, "general_stats": {}},
            "footer": {"notes": ["Report generation failed"], "generated_by": "Enhanced Data Quality System"}
        }

# Add other necessary endpoints with similar optimizations...
@app.route('/api/quality-report/<dataset_id>')
def get_quality_report(dataset_id):
    if dataset_id not in quality_reports:
        return jsonify({'error': 'Quality report not found'}), 404
    
    report = quality_reports[dataset_id].copy()
    
    # Add preview if available
    if dataset_id in datasets:
        df = datasets[dataset_id]['data']
        report['preview'] = get_safe_preview(df)
    
    return jsonify(report)

@app.route('/api/comprehensive-report/<dataset_id>')
def get_comprehensive_report(dataset_id):
    """Get comprehensive report for a specific dataset"""
    if dataset_id not in datasets:
        return jsonify({'error': 'Dataset not found'}), 404
    
    try:
        # Try to load from saved report first
        dataset_info = datasets[dataset_id]
        filename = dataset_info['filename']
        dataset_dir = f"reports/{dataset_id}_{filename.replace('.', '_')}"
        report_path = os.path.join(dataset_dir, "summary_report.json")
        
        if os.path.exists(report_path):
            with open(report_path, "r", encoding="utf-8") as f:
                report = json.load(f)
            return jsonify(report)
        else:
            # Generate report if not found
            df = datasets[dataset_id]['data']
            report = generate_comprehensive_report(df, dataset_id, filename)
            return jsonify(report)
    except Exception as e:
        print(f"❌ Error getting comprehensive report: {e}")
        return jsonify({'error': f'Failed to get comprehensive report: {str(e)}'}), 500

@app.route('/api/datasets')
def get_datasets():
    """Get list of all uploaded datasets"""
    dataset_list = []
    for dataset_id, info in datasets.items():
        dataset_list.append({
            'dataset_id': dataset_id,
            'filename': info['filename'],
            'rows': info['rows'],
            'columns': info['columns'],
            'file_size': info['file_size'],
            'uploaded_at': info['uploaded_at']
        })
    return jsonify(dataset_list)

@app.route('/api/clean-dataset/<dataset_id>', methods=['POST'])
def clean_dataset(dataset_id):
    """Apply data cleaning and transformations based on quality report suggestions"""
    try:
        print(f"🧹 Starting data cleaning for dataset {dataset_id}...")
        
        # Check if dataset exists in memory
        if dataset_id not in datasets:
            return jsonify({'error': 'Dataset not found'}), 404
        
        # Get dataset from memory
        dataset_info = datasets[dataset_id]
        df = dataset_info['data'].copy()
        filename = dataset_info['filename']
        
        print(f"📊 Loaded dataset: {df.shape[0]} rows × {df.shape[1]} columns")
        
        # Load quality report from memory
        if dataset_id in quality_reports:
            quality_report = quality_reports[dataset_id]
        else:
            # Try to load from saved report
            dataset_dir = f"reports/{dataset_id}_{filename.replace('.', '_')}"
            report_path = os.path.join(dataset_dir, "summary_report.json")
            if os.path.exists(report_path):
                with open(report_path, "r", encoding="utf-8") as f:
                    quality_report = json.load(f)
            else:
                return jsonify({'error': 'Quality report not found'}), 404
        
        # Initialize cleaning engine
        cleaning_engine = EnhancedDataCleaningEngine()
        
        # Clean the dataset with quality report
        cleaned_df, cleaning_report = cleaning_engine.clean_dataset_with_report(df, quality_report, dataset_id)
        
        # Save cleaned dataset to memory and disk
        cleaned_id = f"cleaned_{dataset_id}_{int(time.time())}"
        
        # Create datasets directory if it doesn't exist
        os.makedirs("datasets", exist_ok=True)
        cleaned_path = f"datasets/{cleaned_id}.csv"
        cleaned_df.to_csv(cleaned_path, index=False)
        
        # Store cleaned dataset in memory
        datasets[cleaned_id] = {
            'data': cleaned_df,
            'filename': f"cleaned_{filename}",
            'uploaded_at': datetime.now().isoformat(),
            'file_size': cleaned_df.memory_usage(deep=True).sum(),
            'rows': len(cleaned_df),
            'columns': len(cleaned_df.columns)
        }
        
        # Generate quality report for cleaned dataset
        cleaned_quality_report = create_fast_quality_report(cleaned_df)
        
        # Store quality report in memory
        quality_reports[cleaned_id] = cleaned_quality_report
        
        # Save cleaning report
        cleaning_report_path = f"reports/{cleaned_id}_cleaning_report.json"
        os.makedirs(os.path.dirname(cleaning_report_path), exist_ok=True)
        with open(cleaning_report_path, 'w', encoding='utf-8') as f:
            json.dump(cleaning_report, f, indent=2)
        
        print(f"✅ Data cleaning completed!")
        print(f"📁 Cleaned dataset saved: {cleaned_path}")
        print(f"📁 Cleaning report saved: {cleaning_report_path}")
        
        return jsonify({
            'cleaned_id': cleaned_id,
            'original_shape': [df.shape[0], df.shape[1]],
            'cleaned_shape': [cleaned_df.shape[0], cleaned_df.shape[1]],
            'quality_report': cleaned_quality_report,
            'cleaning_report': cleaning_report,
            'preview': create_safe_preview(cleaned_df),
            'download_url': f'/api/download-dataset/{cleaned_id}'
        })
        
    except Exception as e:
        print(f"❌ Error cleaning dataset: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/download-dataset/<dataset_id>', methods=['GET'])
def download_dataset(dataset_id):
    """Download cleaned dataset as CSV"""
    try:
        # Check if dataset exists in memory first
        if dataset_id in datasets:
            df = datasets[dataset_id]['data']
            filename = datasets[dataset_id]['filename']
            
            # Create temporary file for download
            temp_fd, temp_path = tempfile.mkstemp(suffix='.csv')
            df.to_csv(temp_path, index=False)
            
            return send_file(
                temp_path,
                as_attachment=True,
                download_name=filename,
                mimetype='text/csv'
            )
        
        # Fallback to file system
        dataset_path = f"datasets/{dataset_id}.csv"
        if os.path.exists(dataset_path):
            return send_file(
                dataset_path,
                as_attachment=True,
                download_name=f"{dataset_id}.csv",
                mimetype='text/csv'
            )
        
        return jsonify({'error': 'Dataset not found'}), 404
        
    except Exception as e:
        print(f"❌ Error downloading dataset: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/download/<dataset_id>', methods=['GET'])
def download_merged_dataset(dataset_id):
    """Download merged dataset as CSV"""
    try:
        # Check if dataset exists in memory
        if dataset_id in datasets:
            df = datasets[dataset_id]['data']
            filename = datasets[dataset_id]['filename']
            
            # Create temporary file for download
            temp_fd, temp_path = tempfile.mkstemp(suffix='.csv')
            df.to_csv(temp_path, index=False)
            
            return send_file(
                temp_path,
                as_attachment=True,
                download_name=filename,
                mimetype='text/csv'
            )
        
        return jsonify({'error': 'Dataset not found'}), 404
        
    except Exception as e:
        print(f"❌ Error downloading merged dataset: {e}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/debug-datasets', methods=['GET'])
def debug_datasets():
    """Debug endpoint to see what datasets are stored"""
    try:
        debug_info = {
            'total_datasets': len(datasets),
            'dataset_ids': list(datasets.keys()),
            'datasets': {}
        }
        
        for dataset_id, dataset_info in datasets.items():
            df = dataset_info['data']
            debug_info['datasets'][dataset_id] = {
                'filename': dataset_info['filename'],
                'rows': len(df),
                'columns': len(df.columns),
                'column_names': list(df.columns)[:10]  # First 10 columns
            }
        
        response = jsonify(debug_info)
        response.headers.add("Access-Control-Allow-Origin", "*")
        return response
        
    except Exception as e:
        error_response = jsonify({'error': str(e)})
        error_response.headers.add("Access-Control-Allow-Origin", "*")
        return error_response, 500

@app.route('/api/common-keys', methods=['POST'])
def get_common_keys():
    """Get common keys between all datasets"""
    try:
        data = request.get_json()
        datasets_to_analyze = data.get('datasets', [])
        
        if len(datasets_to_analyze) < 2:
            response = jsonify({'error': 'At least 2 datasets are required for key detection'})
            response.headers.add("Access-Control-Allow-Origin", "*")
            return response, 400
        
        # Get all column names from all datasets
        all_columns = {}
        for dataset in datasets_to_analyze:
            dataset_id = dataset.get('dataset_id', f"dataset_{len(all_columns)}")
            schema = dataset.get('schema', [])
            columns = [col.get('column', col) if isinstance(col, dict) else col for col in schema]
            
            all_columns[dataset_id] = {
                'filename': dataset.get('filename', 'Unknown'),
                'columns': columns,
                'row_count': dataset.get('rows', 0)
            }
        
        # Find common columns across all datasets
        if len(all_columns) > 0:
            common_columns = set(list(all_columns.values())[0]['columns'])
            for dataset_info in all_columns.values():
                common_columns = common_columns.intersection(set(dataset_info['columns']))
        
        # Analyze each common column for merge suitability
        merge_candidates = []
        for col in common_columns:
            col_analysis = {
                'column': col,
                'datasets': {},
                'total_unique_values': 0,
                'merge_suitability': 'unknown'
            }
            
            # Analyze this column in each dataset
            for dataset_id, dataset_info in all_columns.items():
                # Since we don't have the actual data, we'll use mock analysis
                # In a real implementation, you'd need to pass the actual data
                col_analysis['datasets'][dataset_id] = {
                    'filename': dataset_info['filename'],
                    'unique_values': 100,  # Mock value
                    'null_count': 0,  # Mock value
                    'null_percentage': 0.0,  # Mock value
                    'sample_values': [f'sample_{i}' for i in range(3)]  # Mock values
                }
            
            # Calculate total unique values across all datasets
            all_values = set()
            for dataset_id in all_columns.keys():
                # Mock calculation
                all_values.update([f'value_{i}' for i in range(100)])
            
            col_analysis['total_unique_values'] = len(all_values)
            
            # Determine merge suitability
            null_percentages = [info['null_percentage'] for info in col_analysis['datasets'].values()]
            avg_null_pct = sum(null_percentages) / len(null_percentages)
            
            if avg_null_pct > 50:
                col_analysis['merge_suitability'] = 'poor'
            elif avg_null_pct > 20:
                col_analysis['merge_suitability'] = 'fair'
            elif col_analysis['total_unique_values'] < 1000:  # Good for categorical keys
                col_analysis['merge_suitability'] = 'good'
            else:
                col_analysis['merge_suitability'] = 'excellent'
            
            merge_candidates.append(col_analysis)
        
        # Sort by suitability and total unique values
        suitability_order = {'excellent': 4, 'good': 3, 'fair': 2, 'poor': 1, 'unknown': 0}
        merge_candidates.sort(key=lambda x: (suitability_order[x['merge_suitability']], -x['total_unique_values']))
        
        result = {
            'common_keys': merge_candidates,
            'total_datasets': len(datasets_to_analyze),
            'dataset_info': all_columns
        }
        
        print(f"🔑 Found {len(common_columns)} common keys across {len(datasets_to_analyze)} datasets")
        response = jsonify(result)
        response.headers.add("Access-Control-Allow-Origin", "*")
        return response
        
    except Exception as e:
        print(f"❌ Error detecting common keys: {e}")
        error_response = jsonify({'error': str(e)})
        error_response.headers.add("Access-Control-Allow-Origin", "*")
        return error_response, 500

@app.route('/api/merge', methods=['OPTIONS'])
def merge_options():
    """Handle CORS preflight for merge endpoint"""
    response = make_response()
    response.headers.add("Access-Control-Allow-Origin", "*")
    response.headers.add('Access-Control-Allow-Headers', "*")
    response.headers.add('Access-Control-Allow-Methods', "*")
    return response

@app.route('/api/merge', methods=['POST'])
def merge_datasets():
    """Merge multiple datasets using advanced merging engine"""
    try:
        data = request.get_json()
        merge_key = data.get('merge_key')
        datasets_to_merge = data.get('datasets', [])
        
        if not merge_key:
            response = jsonify({'error': 'Merge key is required'})
            response.headers.add("Access-Control-Allow-Origin", "*")
            return response, 400
        
        if len(datasets_to_merge) < 2:
            response = jsonify({'error': 'At least 2 datasets are required for merging'})
            response.headers.add("Access-Control-Allow-Origin", "*")
            return response, 400
        
        print(f"🔄 Starting advanced merge with key: {merge_key}")
        print(f"📊 Merging {len(datasets_to_merge)} datasets")
        
        # Initialize advanced merging engine
        merging_engine = AdvancedMergingEngine()
        
        # Perform advanced merge
        merged_df, merge_report = merging_engine.perform_advanced_merge(datasets_to_merge, merge_key)
        
        # Store merged dataset
        merged_id = f"merged_{int(time.time())}"
        datasets[merged_id] = {
            'data': merged_df,
            'filename': f'golden_record_{merged_id}.csv',
            'upload_time': time.time(),
            'merge_info': merge_report
        }
        
        # Create preview (first 5 rows)
        preview = merged_df.head(5).to_dict('records')
        
        # Clean NaN values for JSON serialization
        for record in preview:
            for key, value in record.items():
                if pd.isna(value):
                    record[key] = None
        
        # Generate quality summary
        quality_summary = {
            'rows': len(merged_df),
            'columns': len(merged_df.columns),
            'completeness': merge_report['data_quality']['completeness'],
            'conflicts_detected': merge_report['merge_summary']['conflicts_resolved'],
            'features_created': merge_report['feature_engineering']['features_created'],
            'merge_time': merge_report['merge_summary']['merge_time_seconds']
        }
        
        result = {
            'merged_dataset_id': merged_id,
            'preview': preview,
            'merge_info': merge_report,
            'quality_summary': quality_summary,
            'success': True
        }
        
        print(f"✅ Advanced merge completed: {len(merged_df)} rows, {len(merged_df.columns)} columns")
        response = jsonify(result)
        response.headers.add("Access-Control-Allow-Origin", "*")
        return response
        
    except Exception as e:
        print(f"❌ Error merging datasets: {e}")
        error_response = jsonify({'error': str(e)})
        error_response.headers.add("Access-Control-Allow-Origin", "*")
        return error_response, 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True, threaded=True)
